import 'package:cached_network_image/cached_network_image.dart';
import 'package:dreamcast/utils/image_constant.dart';
import 'package:dreamcast/utils/size_utils.dart';
import 'package:dreamcast/view/exhibitors/controller/exhibitorsController.dart';
import 'package:dreamcast/view/photobooth/controller/photobooth_controller.dart';
import 'package:dreamcast/widgets/app_bar/appbar_leading_image.dart';
import 'package:dreamcast/widgets/app_bar/custom_app_bar.dart';
import 'package:dreamcast/widgets/fullscreen_image.dart';
import 'package:dreamcast/widgets/toolbarTitle.dart';
import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_getx_widget.dart';
import 'package:get/get_utils/src/extensions/internacionalization.dart';
import 'package:get/route_manager.dart';

class AiGallerySliderWidget extends StatefulWidget {
  final selectedIndex;
  const AiGallerySliderWidget({super.key, required this.selectedIndex});

  @override
  State<AiGallerySliderWidget> createState() => _AiGallerySliderWidgetState();
}

class _AiGallerySliderWidgetState extends State<AiGallerySliderWidget> {
  late PageController _pageController;
  int selectedIndex = 0;
  ScrollController _thumbScrollController = ScrollController();

  PhotoBoothController photoBoothController = PhotoBoothController();

  @override
  void initState() {
    super.initState();
    selectedIndex = widget.selectedIndex;
    _pageController = PageController(initialPage: selectedIndex);
    // Add a small delay to ensure the widget builds first
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToThumbnail(selectedIndex);
    });
  }



  void _scrollToThumbnail(int index) {
    final offset = (index * 82.0) - 20; // Adjust based on item size + padding
    _thumbScrollController.animateTo(
      offset,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }


  @override
  void dispose() {
    _pageController.dispose();
    _thumbScrollController.dispose();
    super.dispose();
  }

  void _onThumbnailTap(int index, url) {
    setState(() {
      selectedIndex = index;
    });
    _pageController.animateToPage(index,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut);
    _scrollToThumbnail(index);

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        height: 72.v,
        leadingWidth: 45.h,
        leading: AppbarLeadingImage(
          imagePath: ImageConstant.imgArrowLeft,
          margin: EdgeInsets.only(
            left: 7.h,
            top: 3,
            // bottom: 12.v,
          ),
          onTap: () {
            Get.back();
          },
        ),
        title: ToolbarTitle(
            title: "ai_gallery".tr),
      ),
      body: GetX<PhotoBoothController>(
        builder: (controller){
          return Column(
            children: [
              // Main full screen image viewer
              Expanded(
                child: PageView.builder(
                  controller: _pageController,
                  itemCount: controller.photoList.length,
                  onPageChanged: (index) {
                    setState(() {
                      selectedIndex = index;
                    });
                    _scrollToThumbnail(index);
                    // if (index == widget.imageUrls.length - 1) {
                    //   await loadMoreImages();
                    // }
                  },
                  itemBuilder: (context, index) {
                    return InteractiveViewer(
                      child: CachedNetworkImage(
                        fit: BoxFit.contain,
                        maxHeightDiskCache: 500,
                        imageUrl: controller.photoList[index],
                        placeholder: (context, url) => Center(
                          child: Image.asset(
                            ImageConstant.imagePlaceholder,
                            fit: BoxFit.contain,
                          ),
                        ),
                        errorWidget: (context, url, error) => Image.asset(
                          ImageConstant.imagePlaceholder,
                          fit: BoxFit.contain,
                        ),
                      ),
                    );
                  },
                ),
              ),

              // Thumbnails list
              SizedBox(
                height: 90,
                child: ListView.builder(
                  controller: _thumbScrollController,
                  scrollDirection: Axis.horizontal,
                  itemCount: controller.photoList.length,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  itemBuilder: (context, index) {
                    final isSelected = index == selectedIndex;
                    if (controller.isLoadMoreRunning.value) {
                      return const Center(
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16),
                          child: SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        ),
                      );
                    }
                    return GestureDetector(
                      onTap: () => _onThumbnailTap(index, controller.photoList[index]),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 6),
                        padding: isSelected ? const EdgeInsets.all(3) : null,
                        decoration: BoxDecoration(
                          border: isSelected
                              ? Border.all(color: Colors.blueAccent, width: 2)
                              : null,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: CachedNetworkImage(
                            maxHeightDiskCache: 500,
                            width: 70,
                            height: 70,
                            imageUrl: controller.photoList[index],
                            imageBuilder: (context, imageProvider) => Container(
                              decoration: BoxDecoration(
                                borderRadius: const BorderRadius.all(Radius.circular(10)),
                                image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
                              ),
                            ),
                            placeholder: (context, url) => Center(
                              child: Image.asset(
                                ImageConstant.imagePlaceholder,
                              ),
                            ),
                            errorWidget: (context, url, error) => Image.asset(
                              ImageConstant.imagePlaceholder,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 10),
            ],
          );
        }
      ),
    );
  }
}
