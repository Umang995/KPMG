import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dreamcast/api_repository/api_service.dart';
import 'package:dreamcast/api_repository/app_url.dart';
import 'package:dreamcast/model/erro_code_model.dart';
import 'package:dreamcast/theme/app_colors.dart';
import 'package:dreamcast/utils/image_constant.dart';
import 'package:dreamcast/utils/size_utils.dart';
import 'package:dreamcast/widgets/app_bar/appbar_leading_image.dart';
import 'package:dreamcast/widgets/app_bar/custom_app_bar.dart';
import 'package:dreamcast/widgets/dialog/custom_animated_dialog_widget.dart';
import 'package:dreamcast/widgets/textview/customTextView.dart';
import 'package:dreamcast/widgets/toolbarTitle.dart';
import 'package:flutter/material.dart';
import 'package:get/get_utils/src/extensions/internacionalization.dart';
import 'package:get/route_manager.dart';
import 'package:image_picker/image_picker.dart';
import 'package:multi_image_picker_view/multi_image_picker_view.dart';

class MultiImageUploader extends StatefulWidget {
  final List<XFile> imageFiles;
  // final List<ImageFile> imageFiles;

  const MultiImageUploader({
    required this.imageFiles,
    super.key,
  });

  @override
  State<MultiImageUploader> createState() => _MultiImageUploaderState();
}

class _MultiImageUploaderState extends State<MultiImageUploader> {
  List<double> uploadProgress = [];
  List<bool> isUploaded = [];
  List<XFile> imagesToUpload = [];
  List<double> imageSizesMB = [];


  bool startUploading = false;

  @override
  void initState() {
    super.initState();
    uploadProgress = List.filled(widget.imageFiles.length, 0.0);
    isUploaded = List.filled(widget.imageFiles.length, false);
    imagesToUpload = List.from(widget.imageFiles);
    imageSizesMB = imagesToUpload.map((f) => _getFileSizeInMB(f)).toList();
  }

  double _getFileSizeInMB(XFile file) {
    final bytes = File(file.path).lengthSync();
    return bytes / (1024 * 1024);
  }


  Future<void> _uploadImages() async {
    int startDownloadingLength = 1;
    Dio dio = Dio();

    for (int i = 0; i < imagesToUpload.length; i++) {
      final file = imagesToUpload[i];

      if (!mounted || !imagesToUpload.contains(file)) continue;

      final fileSize = await File(file.path).length();
      final sizeInMB = fileSize / (1024 * 1024);

      setState(() {
        imageSizesMB[i] = sizeInMB;
      });

      FormData formData = FormData.fromMap({
        "image": await MultipartFile.fromFile(file.path, filename: "image_$i.jpg"),
        "type": "file",
      });

      try {
       final response =  await dio.post(
          AppUrl.uploadAiPhoto,
          data: formData,
          onSendProgress: (sent, total) {
            if (total != -1) {
              setState(() {
                uploadProgress[i] = sent / total;
              });
            }
          },
          options: Options(
            headers: ApiService().getHeaders(isMultipart: true)
          ),
        );
       if (response.statusCode == 200) {
         final responseData = response.data;
         if (responseData is String) {
           final decoded = json.decode(responseData);
           if (ErrorCodeModel.fromJson(decoded).code == 440) {
             ApiService().tokenExpire(AppUrl.uploadAiPhoto);
           }
           if(imagesToUpload.length == startDownloadingLength){
             await Get.dialog(
                 barrierDismissible: false,
                 CustomAnimatedDialogWidget(
                   title: "",
                   logo: ImageConstant.icSuccessAnimated,
                   description: decoded['message'] ?? "Images successfully uploaded",
                   buttonAction: "okay".tr,
                   buttonCancel: "cancel".tr,
                   isHideCancelBtn: true,
                   onCancelTap: () {},
                   onActionTap: () async {
                     Get.back();
                     setState(() {});
                   },
                 ));
             break;
           }
           setState(() {
             isUploaded[i] = true;
             startDownloadingLength++;
           });
         } else if (responseData is Map<String, dynamic>) {
           if (ErrorCodeModel.fromJson(responseData).code == 440) {
             ApiService().tokenExpire(AppUrl.uploadAiPhoto);
           }
           if(imagesToUpload.length == startDownloadingLength){
             await Get.dialog(
                 barrierDismissible: false,
                 CustomAnimatedDialogWidget(
                   title: "",
                   logo: ImageConstant.icSuccessAnimated,
                   description: responseData['message'] ?? "Images successfully uploaded",
                   buttonAction: "okay".tr,
                   buttonCancel: "cancel".tr,
                   isHideCancelBtn: true,
                   onCancelTap: () {},
                   onActionTap: () async {
                     Get.back();
                     setState(() {});
                   },
                 ));
             break;
           }
           setState(() {
             isUploaded[i] = true;
             startDownloadingLength++;
           });
         }
       }
      } catch (e) {
        print("Upload failed for image $i: $e");
        setState(() {
          isUploaded[i] = false;
        });
      }
    }
  }


  void _removeImage(int index) {
    setState(() {
      imagesToUpload.removeAt(index);
      uploadProgress.removeAt(index);
      isUploaded.removeAt(index);
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        height: 72.v,
        leadingWidth: 45.h,
        leading: AppbarLeadingImage(
          imagePath: ImageConstant.imgArrowLeft,
          margin: EdgeInsets.only(
            left: 7.h,
            top: 3,
            // bottom: 12.v,
          ),
          onTap: () {
            Get.back();
          },
        ),
        title: const ToolbarTitle(
            title: "Uploads"),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
      floatingActionButton: !startUploading
          ? Align(
        alignment: Alignment.bottomCenter,
        child: Padding(
          padding: const EdgeInsets.only(top: 40),
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: colorPrimary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
              padding: const EdgeInsets.symmetric(
                  vertical: 8, horizontal: 20),
            ),
            onPressed: () {
              setState(() {
                startUploading = true;
              });
              _uploadImages();
            },
            icon: Icon(Icons.upload, color: white),
            label: CustomTextView(
                text: "Upload",
                color: white,
                fontSize: 16,
                fontWeight: FontWeight.w600),
          ),
        ),
      )
          : const SizedBox(),
      body: ListView.builder(
        itemCount: imagesToUpload.length,
        itemBuilder: (context, index) {
          final file = imagesToUpload[index];

          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            padding: const EdgeInsets.symmetric(vertical: 5),
            decoration: BoxDecoration(
              color: lightGray,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Stack(
              alignment: Alignment.topRight,
              children: [
                ListTile(
                  title: CustomTextView(
                    text: file.path.length > 20
                      ? file.path.substring(file.path.length - 20)
                      : file.path,
                    fontSize: 18,
                    color: colorSecondary,
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 7.v),
                      if(startUploading)
                      LinearProgressIndicator(
                        backgroundColor: defaultCheckboxColor,
                        borderRadius: BorderRadius.circular(10),
                        value: uploadProgress[index],
                        color: isUploaded[index] ? Colors.green : colorInvitationSent,
                      ),
                      if(startUploading) SizedBox(height: 5.v),
                      Row(
                        children: [
                          if(startUploading)
                          uploadProgress[index] * 100 == 100
                              ? const SizedBox()
                              : CustomTextView(
                            text: "${(uploadProgress[index] * 100).toStringAsFixed(0)}%",
                          ),
                          uploadProgress[index] * 100 == 100
                              ? const CustomTextView(text: "Uploaded ✅")
                              : const CustomTextView(text: " Uploading... / "),
                          imageSizesMB[index] != null
                              ? uploadProgress[index] * 100 == 100
                              ? const SizedBox()
                              :  CustomTextView(
                            text: "${imageSizesMB[index]!.toStringAsFixed(2)} MB",
                            fontSize: 14,
                            color: colorPrimary,
                          )
                              : const SizedBox(),
                        ],
                      ),


                    ],
                  ),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.file(
                      File(file.path),
                      width: 50,
                      height: 50,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                uploadProgress[index] * 100 == 100
                    ? const SizedBox()
                    : Padding(
                  padding: const EdgeInsets.only(right: 5.0),
                  child: InkWell(
                      onTap: () {
                        setState(() {
                          _removeImage(index);
                        });
                      },
                      child: Icon(Icons.highlight_remove, color: colorSecondary, size: 25)),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
